import { Router } from 'express';
import { requireAuth, requireRole } from '../middlewares/auth.js';
import { createReport, searchReports, listMyReports, deleteReport, purgeOrphans, countOrphans, listAllReports, approveReport, rejectReport } from '../controllers/reports.controller.js';
import { validate, validateQuery } from '../middlewares/validate.js';
import { createReportSchema, searchReportsSchema } from '../validators/reports.schema.js';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { ensureAtLeastOnePhoto } from '../middlewares/ensurePhotos.js';

const router = Router();

// Multer storage (store files in ../../uploads)
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const uploadsDir = path.resolve(__dirname, '../../uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}
const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, uploadsDir),
  filename: (_, file, cb) => {
    const ext = path.extname(file.originalname || '');
    const base = Date.now() + '-' + Math.round(Math.random()*1e9);
    cb(null, base + ext);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 2 * 1024 * 1024 }, // 2MB/ไฟล์
  fileFilter: (_req, file, cb) => {
    if ((file.mimetype || '').startsWith('image/')) return cb(null, true);
    return cb(new Error('เฉพาะไฟล์รูปภาพเท่านั้น'));
  }
});

// ทั้งสาม endpoint ต้อง login ตาม flow ของ frontend ตอนนี้
router.get('/search', requireAuth, validateQuery(searchReportsSchema), searchReports);
router.post('/', requireAuth, upload.array('photos', 3), ensureAtLeastOnePhoto, validate(createReportSchema), createReport);
router.get('/mine', requireAuth, listMyReports);
router.delete('/:id', requireAuth, deleteReport);
// admin utilities
router.get('/_orphans/count', requireAuth, requireRole('admin'), countOrphans);
router.delete('/_orphans/purge', requireAuth, requireRole('admin'), purgeOrphans);
router.get('/admin/all', requireAuth, requireRole('admin'), listAllReports);
router.patch('/:id/approve', requireAuth, requireRole('admin'), approveReport);
router.patch('/:id/reject', requireAuth, requireRole('admin'), rejectReport);

export default router;

